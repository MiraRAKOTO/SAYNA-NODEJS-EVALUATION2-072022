const mysql= require('mysql2');

const con= mysql.createConnection({
    host: process.env.MYSQLHOST,
    user: process.env.MYSQLUSER,
    port: process.env.MYSQLPORT,
    password: process.env.MYSQLPASS,
    database: process.env.MYSQLDATABASE

});

console.log(con)
module.exports=  con 

