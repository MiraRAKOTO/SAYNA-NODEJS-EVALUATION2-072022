require('dotenv').config()
const express= require('express')
const mysql= require('./src/models/mysql')
const app= express()

var bodyParser= require('body-parser');
app.use(bodyParser.json);
app.use(bodyParser.urlencoded({extended: true}));


//console.log(process.env)
 app.get('/',(req,res) => res.send("bonjour"))



 app.get('/sql', function(res,req){
     mysql.query('SELECT*FROM opinion', function(err, results, fields){
         console.log(results);
         console.log(fields)
     })

 })
 app.listen(3700, ()=> console.log("Connexion bien effectuée sur le port 3700"))





 //API index
 app.use(express.static(__dirname,''))
app.get('/index', function(req,res){
    res.sendFile(__dirname+ '/index.html')
})

 //API backend
 app.use(express.static(__dirname,''))
app.get('/backend', function(req,res){
    res.sendFile(__dirname+ '/backend.html')
})

//API contact
app.use(express.static(__dirname,''))
app.get('/contact', function(req,res){
    res.sendFile(__dirname+ '/contact.html')
})

//POST

app.post('/contact', function(req,res){
    var firstname= req.body.firstname;
    var lastname= req.body.lastname;
    var avis= req.body.avis;
    var note= req.body.note;
    var formation= req.body.formation;

    con.connect(function(error){
        if(error) throw error; 
        var sql= "INSERT INTO opinion (firstname, lastname, avis, note, formation) VALUES ('"+firstname+"','"+lastname+"', '"+avis+"','"+note+"' ,'"+formation+"') "
    }
  
  })


//API frontend
app.use(express.static(__dirname,''))
app.get('/frontend', function(req,res){
    res.sendFile(__dirname+ '/frontend.html')
})

//API marketing
app.use(express.static(__dirname,''))
app.get('/marketing', function(req,res){
    res.sendFile(__dirname+ '/marketing.html')
})

//API uxui
app.use(express.static(__dirname,''))
app.get('/uxui', function(req,res){
    res.sendFile(__dirname+ '/uxui.html')
})

//API signup
app.use(express.static(__dirname,''))
app.get('/signup', function(req,res){
    res.sendFile(__dirname+ '/signup.html')
})
